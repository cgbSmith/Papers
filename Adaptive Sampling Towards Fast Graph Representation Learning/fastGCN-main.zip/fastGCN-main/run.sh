#!/bin/sh

echo "Cornell"
python train.py --dataset=Cornell --model=Fast
