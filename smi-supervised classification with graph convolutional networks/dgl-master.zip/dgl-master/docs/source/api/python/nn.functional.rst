.. _apinn-functional:

dgl.nn.functional
=================

.. automodule:: dgl.nn.functional

.. autosummary::
    :toctree: ../../generated/

   edge_softmax
