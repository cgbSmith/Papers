MXNET_CUDNN_AUTOTUNE_DEFAULT=0 python train_reldn.py \
    --pretrained-faster-rcnn-params faster_rcnn_resnet101_v1d_visualgenome/faster_rcnn_resnet101_v1d_custom_best.params
