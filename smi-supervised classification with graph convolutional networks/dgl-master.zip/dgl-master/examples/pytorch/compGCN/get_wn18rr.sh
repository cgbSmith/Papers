wget https://dgl-data.s3.cn-north-1.amazonaws.com.cn/dataset/wn18rr.zip
unzip wn18rr.zip
