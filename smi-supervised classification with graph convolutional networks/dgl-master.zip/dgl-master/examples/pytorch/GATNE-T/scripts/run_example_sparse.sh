python src/main_sparse.py --input data/example --gpu 0
