python src/main.py --input data/example --gpu 0
