wget https://s3.us-west-2.amazonaws.com/dgl-data/dataset/gowalla.zip
unzip gowalla.zip