wget https://s3.us-west-2.amazonaws.com/dgl-data/dataset/amazon-book.zip
unzip amazon-book.zip