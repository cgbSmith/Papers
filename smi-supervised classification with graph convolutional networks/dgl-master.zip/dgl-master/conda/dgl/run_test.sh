DGLBACKEND=numpy $PYTHON -c 'import dgl'
